import {rolldown} from 'rolldown';
const b=await rolldown({input:'upstream/src/chessground.ts'});
await b.write({file:'chessground.js',format:'esm',minify:true,banner:'// Chessground 10.5.0, lichess.org contributors. GPL-3.0-or-later. Commit b4f605018e1043640c917e82a74b214cb58e4a05.\n// Matching source: chessground-10.5.0-source.tar.gz; license: Chessground-LICENSE.txt.'});await b.close();
