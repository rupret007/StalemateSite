# Shared Hang Out entry toolkit

Copy neutral-link.html into any existing website. It opens the one approved
community address without a site account, registration, badge or staff power.
Normal invitation/sign-in rules still apply. No credentials belong in links.

Optional registered badges and return links:
1. Review community-integration.example.json and verify each domain separately.
   Every example starts disabled and unverified; this tool verifies no domain.
2. With Node.js 22 or newer, run:
   node scripts/package-community-entry.mjs --config reviewed.json --out NEW_DIRECTORY
3. The community operator must separately configure approved extra badge sites
   in HANGOUT_ENTRY_SITES. The link builder makes no server changes. Disabling
   an integration stops approved-link generation; ordinary links remain valid.

SOURCE-MANIFEST.json binds this toolkit to committed source and hashes every
payload file. Only two fixed module imports are relocated for standalone use;
source-input hashes and delivered-file hashes are recorded separately.
The toolkit does not contain the full app or prove the deployed version.
No cookie copying, cross-site SSO, provider activation or deployment is performed.
Preserve existing site pages and use a new output directory.
